const int BUFFER_SIZE= 10;
